package util;



import java.sql.Connection;
import java.sql.Statement;

public class DatabaseInitializer {
    
    public static void initialize() {
        createTables();
        insertSampleData();
    }
    
    private static void createTables() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create users table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTO_INCREMENT,( " +
                "username TEXT NOT NULL UNIQUE, " +
                "password TEXT NOT NULL, " +
                "role TEXT NOT NULL, " +
                "active BOOLEAN NOT NULL DEFAULT 1" +
                ")"
            );
            
            // Create patients table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS patients (" +
                "id INTEGER PRIMARY KEY AUTO_INCREMENT," +
                "first_name TEXT NOT NULL, " +
                "last_name TEXT NOT NULL, " +
                "date_of_birth DATE NOT NULL, " +
                "phone TEXT, " +
                "email TEXT, " +
                "address TEXT, " +
                "medical_history TEXT" +
                ")"
            );
            
            // Create doctors table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS doctors (" +
                "id INTEGER PRIMARY KEY AUTO_INCREMENT, " +
                "first_name TEXT NOT NULL, " +
                "last_name TEXT NOT NULL, " +
                "specialization TEXT, " +
                "phone TEXT, " +
                "email TEXT, " +
                "schedule TEXT" +
                ")"
            );
            
            // Create appointments table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS appointments (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "patient_id INTEGER NOT NULL, " +
                "doctor_id INTEGER NOT NULL, " +
                "date_time TIMESTAMP NOT NULL, " +
                "duration INTEGER NOT NULL DEFAULT 30, " +
                "reason TEXT, " +
                "notes TEXT, " +
                "status TEXT NOT NULL DEFAULT 'SCHEDULED', " +
                "FOREIGN KEY (patient_id) REFERENCES patients (id) ON DELETE CASCADE, " +
                "FOREIGN KEY (doctor_id) REFERENCES doctors (id) ON DELETE CASCADE" +
                ")"
            );
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static void insertSampleData() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Check if tables are empty
            boolean hasUsers = stmt.executeQuery("SELECT COUNT(*) FROM users").getInt(1) > 0;
            boolean hasPatients = stmt.executeQuery("SELECT COUNT(*) FROM patients").getInt(1) > 0;
            boolean hasDoctors = stmt.executeQuery("SELECT COUNT(*) FROM doctors").getInt(1) > 0;
            
            if (!hasUsers) {
                // Insert default admin user
                stmt.execute("INSERT INTO users (username, password, role, active) " +
                           "VALUES ('admin', 'admin123', 'ADMIN', 1)");
                           
                // Insert default secretary user
                stmt.execute("INSERT INTO users (username, password, role, active) " +
                           "VALUES ('secretary', 'secret123', 'SECRETARY', 1)");
            }
            
            if (!hasPatients) {
                // Insert sample patients
                stmt.execute("INSERT INTO patients (first_name, last_name, date_of_birth, phone, email, address, medical_history) " +
                           "VALUES ('Jean', 'Dupont', '1980-05-15', '0123456789', 'jean.dupont@email.com', '123 Rue de Paris, Paris', 'Allergie au pollen')");
                stmt.execute("INSERT INTO patients (first_name, last_name, date_of_birth, phone, email, address, medical_history) " +
                           "VALUES ('Marie', 'Martin', '1975-10-20', '0987654321', 'marie.martin@email.com', '456 Avenue Victor Hugo, Lyon', 'Hypertension')");
                stmt.execute("INSERT INTO patients (first_name, last_name, date_of_birth, phone, email, address, medical_history) " +
                           "VALUES ('Pierre', 'Bernard', '1990-02-28', '0654321789', 'pierre.bernard@email.com', '789 Boulevard Saint-Michel, Marseille', 'Aucun')");
            }
            
            if (!hasDoctors) {
                // Insert sample doctors
                stmt.execute("INSERT INTO doctors (first_name, last_name, specialization, phone, email, schedule) " +
                           "VALUES ('Sophie', 'Lefebvre', 'Médecin généraliste', '0123789456', 'dr.lefebvre@hopital.com', 'Lundi-Vendredi: 9h-17h')");
                stmt.execute("INSERT INTO doctors (first_name, last_name, specialization, phone, email, schedule) " +
                           "VALUES ('Thomas', 'Moreau', 'Cardiologue', '0789456123', 'dr.moreau@hopital.com', 'Lundi, Mercredi, Vendredi: 8h-16h')");
                stmt.execute("INSERT INTO doctors (first_name, last_name, specialization, phone, email, schedule) " +
                           "VALUES ('Julie', 'Petit', 'Pédiatre', '0456123789', 'dr.petit@hopital.com', 'Mardi, Jeudi: 10h-18h')");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}